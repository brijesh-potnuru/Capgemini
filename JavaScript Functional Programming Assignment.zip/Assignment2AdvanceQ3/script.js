var result = function(x){
    (function(x){
       return x*x;
    }(5))
};


document.write('"'+result+'"');