var a= parseInt(prompt("Enter the currency in dollars"));
document.write("The other currency value of the given dollar value is given below :")
document.write("<br><br>Indian Rupee : "+(74.28*a)+" INR");
document.write("<br>Japanese Yen : "+(109.14*a)+" Yen");
document.write("<br>Euro : "+(0.84*a)+" Euro");
document.write("<br>Pound sterling : "+(0.72*a)+" Pound sterling");