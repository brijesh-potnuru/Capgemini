var a= ["a","b","c"];
var b= [1,2,3];
document.write(a.concat(b));